import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  subtitle?: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  iconColor?: string;
}

export function StatsCard({
  title,
  value,
  icon: Icon,
  subtitle,
  trend,
  iconColor = "text-primary",
}: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
          </div>
          <div className={`h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center`}>
            <Icon className={`text-xl ${iconColor}`} />
          </div>
        </div>
        {(trend || subtitle) && (
          <div className="mt-4 flex items-center text-sm">
            {trend && (
              <>
                <span
                  className={`font-medium ${
                    trend.isPositive ? "text-green-600" : "text-red-600"
                  }`}
                >
                  {trend.value}
                </span>
                <span className="text-gray-500 ml-2">{subtitle}</span>
              </>
            )}
            {!trend && subtitle && (
              <span className="text-gray-500">{subtitle}</span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
