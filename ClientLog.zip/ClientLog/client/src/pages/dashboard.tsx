import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { StatsCard } from "@/components/stats-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Clock, Calendar, Users, TrendingUp, Plus, Briefcase } from "lucide-react";
import { Link } from "wouter";
import { ClientWithStats, TimeEntryWithClient } from "@shared/schema";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<{
    todayHours: number;
    weekHours: number;
    activeClients: number;
    avgProgress: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const { data: recentEntries = [], isLoading: entriesLoading } = useQuery<TimeEntryWithClient[]>({
    queryKey: ["/api/time-entries"],
    queryFn: async () => {
      const res = await fetch("/api/time-entries?limit=5");
      return res.json();
    },
  });

  const { data: clients = [], isLoading: clientsLoading } = useQuery<ClientWithStats[]>({
    queryKey: ["/api/clients"],
  });

  const topClients = clients.slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      
      <div className="ml-64 min-h-screen">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-6 py-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                <p className="text-gray-600 mt-1">Overview of your time tracking</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm text-gray-500">Today</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {statsLoading ? "..." : `${stats?.todayHours || 0}h`}
                  </p>
                </div>
                <Link href="/time-entry">
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Quick Log
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              title="Today's Hours"
              value={statsLoading ? "..." : stats?.todayHours || 0}
              icon={Clock}
              iconColor="text-primary"
            />
            <StatsCard
              title="Week Total"
              value={statsLoading ? "..." : `${stats?.weekHours || 0}h`}
              icon={Calendar}
              iconColor="text-green-600"
              subtitle="hours this week"
            />
            <StatsCard
              title="Active Clients"
              value={statsLoading ? "..." : stats?.activeClients || 0}
              icon={Users}
              iconColor="text-purple-600"
            />
            <StatsCard
              title="Avg. Progress"
              value={statsLoading ? "..." : `${stats?.avgProgress || 0}%`}
              icon={TrendingUp}
              iconColor="text-orange-600"
            />
          </div>

          {/* Recent Activity & Client Progress */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Time Entries */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Time Entries</CardTitle>
              </CardHeader>
              <CardContent>
                {entriesLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse flex space-x-4">
                        <div className="h-10 w-10 bg-gray-200 rounded-lg"></div>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : recentEntries.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No time entries yet</p>
                    <Link href="/time-entry">
                      <Button className="mt-2" size="sm">
                        Log your first entry
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentEntries.map((entry) => (
                      <div
                        key={entry.id}
                        className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Briefcase className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{entry.clientName}</p>
                            <p className="text-sm text-gray-500 truncate max-w-xs">
                              {entry.description}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">{entry.hours}h</p>
                          <p className="text-sm text-gray-500">
                            {new Date(entry.date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div className="text-center pt-4">
                      <Link href="/history">
                        <Button variant="ghost" size="sm">
                          View All Entries
                        </Button>
                      </Link>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Client Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Client Progress</CardTitle>
              </CardHeader>
              <CardContent>
                {clientsLoading ? (
                  <div className="space-y-6">
                    {[...Array(4)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="flex justify-between mb-2">
                          <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                          <div className="h-4 bg-gray-200 rounded w-12"></div>
                        </div>
                        <div className="h-2 bg-gray-200 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : topClients.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No clients yet</p>
                    <Link href="/clients">
                      <Button className="mt-2" size="sm">
                        Add your first client
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {topClients.map((client) => (
                      <div key={client.id}>
                        <div className="flex items-center justify-between mb-2">
                          <p className="font-medium text-gray-900">{client.name}</p>
                          <p className="text-sm font-semibold text-gray-900">
                            {client.totalProgress}%
                          </p>
                        </div>
                        <Progress value={client.totalProgress} className="h-2" />
                        <p className="text-sm text-gray-500 mt-1">
                          {client.description || `${client.totalHours}h total`}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
