import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertTimeEntrySchema, Client } from "@shared/schema";
import { z } from "zod";
import { Save, Calendar } from "lucide-react";
import { useLocation } from "wouter";

const timeEntryFormSchema = insertTimeEntrySchema;

type TimeEntryFormData = z.infer<typeof timeEntryFormSchema>;

export default function TimeEntry() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: clients = [], isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  const form = useForm<TimeEntryFormData>({
    resolver: zodResolver(timeEntryFormSchema),
    defaultValues: {
      clientId: "",
      date: new Date().toISOString().split('T')[0],
      hours: 0,
      progressPercentage: 0,
      description: "",
      notes: "",
    },
  });

  const createTimeEntryMutation = useMutation({
    mutationFn: async (data: TimeEntryFormData) => {
      const res = await apiRequest("POST", "/api/time-entries", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({
        title: "Time entry saved!",
        description: "Your work has been logged successfully.",
      });
      form.reset();
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save entry",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TimeEntryFormData) => {
    createTimeEntryMutation.mutate(data);
  };

  const clearForm = () => {
    form.reset();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      
      <div className="ml-64 min-h-screen">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-6 py-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Log Time Entry</h2>
                <p className="text-gray-600 mt-1">Record your work hours and progress</p>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="p-6">
          <div className="max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5" />
                  <span>Time Entry Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="date">Date</Label>
                      <Input
                        id="date"
                        type="date"
                        {...form.register("date")}
                      />
                      {form.formState.errors.date && (
                        <p className="text-sm text-red-600">
                          {form.formState.errors.date.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="client">Client</Label>
                      <Select
                        value={form.watch("clientId")}
                        onValueChange={(value) => form.setValue("clientId", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a client" />
                        </SelectTrigger>
                        <SelectContent>
                          {clientsLoading ? (
                            <SelectItem value="" disabled>
                              Loading...
                            </SelectItem>
                          ) : clients.length === 0 ? (
                            <SelectItem value="" disabled>
                              No clients available
                            </SelectItem>
                          ) : (
                            clients.map((client) => (
                              <SelectItem key={client.id} value={client.id}>
                                {client.name}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      {form.formState.errors.clientId && (
                        <p className="text-sm text-red-600">
                          {form.formState.errors.clientId.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="hours">Hours Worked</Label>
                      <Input
                        id="hours"
                        type="number"
                        step="0.25"
                        min="0"
                        max="24"
                        placeholder="e.g., 3.5"
                        {...form.register("hours")}
                      />
                      {form.formState.errors.hours && (
                        <p className="text-sm text-red-600">
                          {form.formState.errors.hours.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="progressPercentage">Progress Made (%)</Label>
                      <Input
                        id="progressPercentage"
                        type="number"
                        min="0"
                        max="100"
                        placeholder="e.g., 15"
                        {...form.register("progressPercentage")}
                      />
                      {form.formState.errors.progressPercentage && (
                        <p className="text-sm text-red-600">
                          {form.formState.errors.progressPercentage.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Work Description</Label>
                    <Textarea
                      id="description"
                      rows={4}
                      placeholder="Describe what you worked on today..."
                      {...form.register("description")}
                    />
                    {form.formState.errors.description && (
                      <p className="text-sm text-red-600">
                        {form.formState.errors.description.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      rows={3}
                      placeholder="Any additional notes or blockers..."
                      {...form.register("notes")}
                    />
                  </div>

                  <div className="flex justify-end space-x-4 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={clearForm}
                      disabled={createTimeEntryMutation.isPending}
                    >
                      Clear
                    </Button>
                    <Button
                      type="submit"
                      disabled={createTimeEntryMutation.isPending}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {createTimeEntryMutation.isPending ? "Saving..." : "Save Entry"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
