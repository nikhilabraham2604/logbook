import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertClientSchema, insertTimeEntrySchema } from "@shared/schema";
import { z } from "zod";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Client routes
  app.get("/api/clients", requireAuth, async (req, res, next) => {
    try {
      const clients = await storage.getClients(req.user.id);
      res.json(clients);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/clients", requireAuth, async (req, res, next) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      const client = await storage.createClient({
        ...validatedData,
        userId: req.user.id,
      });
      res.status(201).json(client);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/clients/:id", requireAuth, async (req, res, next) => {
    try {
      const validatedData = insertClientSchema.partial().parse(req.body);
      const client = await storage.updateClient(req.params.id, req.user.id, validatedData);
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/clients/:id", requireAuth, async (req, res, next) => {
    try {
      const success = await storage.deleteClient(req.params.id, req.user.id);
      if (!success) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // Time entry routes
  app.get("/api/time-entries", requireAuth, async (req, res, next) => {
    try {
      const { startDate, endDate, clientId, limit, offset } = req.query;
      const filters = {
        startDate: startDate as string,
        endDate: endDate as string,
        clientId: clientId as string,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      };
      
      const timeEntries = await storage.getTimeEntries(req.user.id, filters);
      res.json(timeEntries);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/time-entries", requireAuth, async (req, res, next) => {
    try {
      // Convert string numbers to actual numbers for validation
      const processedBody = {
        ...req.body,
        hours: Number(req.body.hours),
        progressPercentage: Number(req.body.progressPercentage),
      };
      
      const validatedData = insertTimeEntrySchema.parse(processedBody);
      const timeEntry = await storage.createTimeEntry({
        ...validatedData,
        userId: req.user.id,
      });
      res.status(201).json(timeEntry);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/time-entries/:id", requireAuth, async (req, res, next) => {
    try {
      const validatedData = insertTimeEntrySchema.partial().parse(req.body);
      const timeEntry = await storage.updateTimeEntry(req.params.id, req.user.id, validatedData);
      if (!timeEntry) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.json(timeEntry);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/time-entries/:id", requireAuth, async (req, res, next) => {
    try {
      const success = await storage.deleteTimeEntry(req.params.id, req.user.id);
      if (!success) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // Stats route
  app.get("/api/stats", requireAuth, async (req, res, next) => {
    try {
      const stats = await storage.getStats(req.user.id);
      res.json(stats);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
