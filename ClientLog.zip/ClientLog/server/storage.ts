import { 
  users, 
  clients, 
  timeEntries, 
  type User, 
  type InsertUser, 
  type Client, 
  type InsertClient, 
  type TimeEntry, 
  type InsertTimeEntry,
  type ClientWithStats,
  type TimeEntryWithClient 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, gte, lte } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getClients(userId: string): Promise<ClientWithStats[]>;
  getClient(id: string, userId: string): Promise<Client | undefined>;
  createClient(client: InsertClient & { userId: string }): Promise<Client>;
  updateClient(id: string, userId: string, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: string, userId: string): Promise<boolean>;
  
  getTimeEntries(userId: string, filters?: {
    startDate?: string;
    endDate?: string;
    clientId?: string;
    limit?: number;
    offset?: number;
  }): Promise<TimeEntryWithClient[]>;
  getTimeEntry(id: string, userId: string): Promise<TimeEntry | undefined>;
  createTimeEntry(timeEntry: InsertTimeEntry & { userId: string }): Promise<TimeEntry>;
  updateTimeEntry(id: string, userId: string, timeEntry: Partial<InsertTimeEntry>): Promise<TimeEntry | undefined>;
  deleteTimeEntry(id: string, userId: string): Promise<boolean>;
  
  getStats(userId: string): Promise<{
    todayHours: number;
    weekHours: number;
    activeClients: number;
    avgProgress: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getClients(userId: string): Promise<ClientWithStats[]> {
    const clientsWithStats = await db
      .select({
        id: clients.id,
        name: clients.name,
        industry: clients.industry,
        description: clients.description,
        userId: clients.userId,
        createdAt: clients.createdAt,
        totalHours: sql<number>`COALESCE(SUM(${timeEntries.hours}::numeric), 0)`,
        weekHours: sql<number>`COALESCE(SUM(CASE WHEN ${timeEntries.date} >= CURRENT_DATE - INTERVAL '7 days' THEN ${timeEntries.hours}::numeric ELSE 0 END), 0)`,
        totalProgress: sql<number>`COALESCE(SUM(${timeEntries.progressPercentage}), 0)`,
        lastActivity: sql<string>`MAX(${timeEntries.date})::text`,
      })
      .from(clients)
      .leftJoin(timeEntries, eq(clients.id, timeEntries.clientId))
      .where(eq(clients.userId, userId))
      .groupBy(clients.id)
      .orderBy(desc(clients.createdAt));

    return clientsWithStats;
  }

  async getClient(id: string, userId: string): Promise<Client | undefined> {
    const [client] = await db
      .select()
      .from(clients)
      .where(and(eq(clients.id, id), eq(clients.userId, userId)));
    return client || undefined;
  }

  async createClient(client: InsertClient & { userId: string }): Promise<Client> {
    const [newClient] = await db
      .insert(clients)
      .values(client)
      .returning();
    return newClient;
  }

  async updateClient(id: string, userId: string, client: Partial<InsertClient>): Promise<Client | undefined> {
    const [updatedClient] = await db
      .update(clients)
      .set(client)
      .where(and(eq(clients.id, id), eq(clients.userId, userId)))
      .returning();
    return updatedClient || undefined;
  }

  async deleteClient(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(clients)
      .where(and(eq(clients.id, id), eq(clients.userId, userId)));
    return result.rowCount! > 0;
  }

  async getTimeEntries(userId: string, filters: {
    startDate?: string;
    endDate?: string;
    clientId?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<TimeEntryWithClient[]> {
    // Apply filters
    const conditions = [eq(timeEntries.userId, userId)];
    
    if (filters.startDate) {
      conditions.push(gte(timeEntries.date, filters.startDate));
    }
    
    if (filters.endDate) {
      conditions.push(lte(timeEntries.date, filters.endDate));
    }
    
    if (filters.clientId) {
      conditions.push(eq(timeEntries.clientId, filters.clientId));
    }

    let query = db
      .select({
        id: timeEntries.id,
        userId: timeEntries.userId,
        clientId: timeEntries.clientId,
        date: timeEntries.date,
        hours: timeEntries.hours,
        progressPercentage: timeEntries.progressPercentage,
        description: timeEntries.description,
        notes: timeEntries.notes,
        createdAt: timeEntries.createdAt,
        clientName: clients.name,
      })
      .from(timeEntries)
      .innerJoin(clients, eq(timeEntries.clientId, clients.id))
      .where(and(...conditions))
      .orderBy(desc(timeEntries.date), desc(timeEntries.createdAt));

    if (filters.limit) {
      query = query.limit(filters.limit);
    }

    if (filters.offset) {
      query = query.offset(filters.offset);
    }

    return await query;
  }

  async getTimeEntry(id: string, userId: string): Promise<TimeEntry | undefined> {
    const [timeEntry] = await db
      .select()
      .from(timeEntries)
      .where(and(eq(timeEntries.id, id), eq(timeEntries.userId, userId)));
    return timeEntry || undefined;
  }

  async createTimeEntry(timeEntry: InsertTimeEntry & { userId: string }): Promise<TimeEntry> {
    const [newTimeEntry] = await db
      .insert(timeEntries)
      .values(timeEntry)
      .returning();
    return newTimeEntry;
  }

  async updateTimeEntry(id: string, userId: string, timeEntry: Partial<InsertTimeEntry>): Promise<TimeEntry | undefined> {
    const [updatedTimeEntry] = await db
      .update(timeEntries)
      .set(timeEntry)
      .where(and(eq(timeEntries.id, id), eq(timeEntries.userId, userId)))
      .returning();
    return updatedTimeEntry || undefined;
  }

  async deleteTimeEntry(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(timeEntries)
      .where(and(eq(timeEntries.id, id), eq(timeEntries.userId, userId)));
    return result.rowCount! > 0;
  }

  async getStats(userId: string): Promise<{
    todayHours: number;
    weekHours: number;
    activeClients: number;
    avgProgress: number;
  }> {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const [stats] = await db
      .select({
        todayHours: sql<number>`COALESCE(SUM(CASE WHEN ${timeEntries.date} = ${today} THEN ${timeEntries.hours}::numeric ELSE 0 END), 0)`,
        weekHours: sql<number>`COALESCE(SUM(CASE WHEN ${timeEntries.date} >= ${weekAgo} THEN ${timeEntries.hours}::numeric ELSE 0 END), 0)`,
        activeClients: sql<number>`COUNT(DISTINCT ${timeEntries.clientId})`,
        avgProgress: sql<number>`COALESCE(AVG(${timeEntries.progressPercentage}), 0)`,
      })
      .from(timeEntries)
      .where(eq(timeEntries.userId, userId));

    return {
      todayHours: Number(stats.todayHours),
      weekHours: Number(stats.weekHours),
      activeClients: Number(stats.activeClients),
      avgProgress: Math.round(Number(stats.avgProgress)),
    };
  }
}

export const storage = new DatabaseStorage();
